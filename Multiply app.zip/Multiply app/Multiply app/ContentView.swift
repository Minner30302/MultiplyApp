//
//  ContentView.swift
//  Multiply app
//
//  Created by Lopez, Emre - Student on 2/5/24.
//

import SwiftUI

struct ContentView: View {
    
//    @State private var TextFieldText: String = ""
    @State private var number = 0
    @State private var number2 = 0
    @State private var Total = 0
            
    var body: some View {
        VStack {
            
            Text("Multiply")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            TextField("Number", value: $number, format: .number)
                    .font(.title)
                   .multilineTextAlignment(.center)
            
            
            TextField("Number", value: $number2, format: .number)
                    .font(.title)
                   .multilineTextAlignment(.center)
            
            Button(action: {
                Total = number * number2
            }, label: {
                
                Text("Multiply")
                    .fontWeight(.bold)
                    .foregroundColor(.red)
            })
            .padding()
            
        Text("Your Total is \(Total).")
            
                .padding()
            
            
            
            Button(action: {
                Total = 0
                number = 0
                number2 = 0
            }, label: {
                Text("Reset")
                    .fontWeight(.bold)
                    .foregroundColor(.gray)
            })
                
            
            
      }
        .padding()
    }
}

#Preview {
    ContentView()
}
