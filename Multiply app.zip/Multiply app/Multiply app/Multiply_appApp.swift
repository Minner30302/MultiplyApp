//
//  Multiply_appApp.swift
//  Multiply app
//
//  Created by Lopez, Emre - Student on 2/5/24.
//

import SwiftUI

@main
struct Multiply_appApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
